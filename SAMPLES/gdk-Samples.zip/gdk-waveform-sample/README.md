Waveform
========

This sample launches an immersion that receives audio input from the microphone
and displays it on the screen as an animated waveform, along with the decibel
level.

## Getting started

Check out our documentation to learn how to get started on
https://developers.google.com/glass/develop/index

## Running the sample on Glass

You can use your IDE to compile and install the sample or use
[`adb`](https://developer.android.com/tools/help/adb.html)
on the command line:

    $ adb install -r WaveformSample.apk

To start the sample, say "ok glass, show me a demo" from the Glass clock
screen or use the touch menu.
